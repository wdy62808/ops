#!/bin/bash

set -u
set -e

# 配置文件
bk_conf_file=/data/tools/bk_agent_script/bk_script.conf

# 解析bk_script.conf配置项
function getScriptConf()
{
    if [ $# -lt 1 ]; then echo "$0 env_d|env_g"; exit 1; fi
    env=$1
    
    # 遍历section下所有key=value
    curr_section=""
    not_match="------<||>------NotMatch------<||>------"
    while read line
    do
        # trim 前后空格
        trim_line=`echo "$line" | sed -e 's/^\s*//' -e 's/\s*$//'`
        if [[ $trim_line == "" ]]; then
            continue
        fi

        # 以#开头的注释
        comment=$(echo $trim_line | grep "^#" || echo $not_match)
        if [[ $comment != $not_match ]]; then 
            continue
        fi
        
        section=$(echo $trim_line | grep "^\[.*\]$" || echo $not_match)
        if [[ $section != $not_match ]]; then
            curr_section=$section
            continue
        fi

        if [[ $curr_section == "[$env]" ]]; then
            key=`echo $trim_line | awk -F'=' '{print $1}'`
            value=`echo $trim_line | awk -F'=' '{for(i=2;i<=NF-1;++i) printf $i"="}END{ if(NF>1) print $NF}'`
            
            if [[ "$value"x == ""x ]];then
                echo "配置格式错误: "$trim_line
                exit -1
            fi
            
            eval $key="\""$value"\""
        fi
    done < $bk_conf_file
}

# 默认读取global/env_g配置
getScriptConf global
getScriptConf env_g


# 解析HostList配置, 获取host和port
# Useage: 
# parseHostListCfg $hostlist host port
# mysql -h$host -p$port
function parseHostListCfg()
{
    if [ $# -lt 3 ]; then echo "$0 hostlist host port"; exit 1; fi

    host_vec=(`echo $1 | awk -F';' '{for(i=1;i<=NF;i++) print $i}'`)
    host_vec_len=${#host_vec[@]}
    if [ $host_vec_len -lt 1 ]; then echo "Host List is empty"; exit 1; fi
    
    random_idx=$(($RANDOM%$host_vec_len))
    host_port=`echo ${host_vec[$random_idx]}`
    
    host_port=(`echo $host_port | awk -F':' '{for(i=1;i<=NF;i++) print $i}'`)
    host_port_len=${#host_port[@]}
    if [ $host_port_len -ne 2 ]; then echo "Host List format error"; exit 1; fi

    eval $2=${host_port[0]}
    eval $3=${host_port[1]}
    return 0
}

# 获取日志文件, 在/tmp目录创建执行脚本名字命名的日志文件(/tmp/xxx.log), 在蓝鲸下执行会得不到原始文件名
# Useage:
# getLogFile $0 log_file
function getLogFile()
{
    if [ $# -lt 2 ]; then echo "$0 script_name log_file"; exit 1; fi

    script_name=$(echo $1 | awk -F'/' '{print $NF}')
    log_file=$(echo $script_name | awk -F".sh" '{print "/tmp/"$1".log"}')

    eval $2=$log_file
}

# run互斥文件锁, 在/tmp目录创建执行脚本名字命名的文件(/tmp/.xxx.pid)
# Useage:
# runLocker $0
# runLocker xxx.sh
function runLocker()
{
    if [ $# -lt 1 ]; then echo "$0 script_name"; exit 1; fi

    script_name=$(echo $1 | awk -F'/' '{print $NF}')
    lock_file=$(echo $script_name | awk -F".sh" '{print "/tmp/."$1".pid"}')
    touch $lock_file
    exec 57<>$lock_file
    flock -xn 57 || lockExit $script_name
}
function lockExit() 
{
    if [ $# -lt 1 ]; then echo "$0 script_name"; exit 1; fi
    script_name=$1
    
    echo "./$script_name is running, pls wariting..."
    exit -1
}

# 获取内网ips
# Useage:
# getInternalIps internal_ips
function getInternalIps()
{
    if [ $# -lt 1 ]; then echo "$0 internal_ips"; exit 1; fi
    ip_list=$(/sbin/ifconfig -a | sed '/^eth\|bond/,+1!d; /inet addr:/!d; s/.*inet addr:\([^ \t]\+\).*/\1/g; /^127\./d' | sort | awk -F. '$1==10 || ($1==192 && $2==168) || ($1==172 && $2>=16 && $2<=31){print}')
    eval $1=$ip_list
}

# 获取所有division
# Useage：
# getAllDivision db_use db_pwd app server divisions
function getAllDivision()
{
    if [ $# -lt 5 ]; then echo "$0 db_use db_pwd app server divisions"; exit 1; fi
    local db_user=$1
    local db_pass=$2
    local app=$3
    local server=$4
    local __retVal=$5

    # select from db
    local sql="select DISTINCT division from db_mfw.t_server where app='$app' and server='$server'"
    parseHostListCfg $db_hostlist_global db_ip db_port
    local divisions=$(echo $sql|mysql -h$db_ip -P$db_port -u$db_user -p$db_pass -N)

    eval $__retVal="'$divisions'"
    return 0
}

