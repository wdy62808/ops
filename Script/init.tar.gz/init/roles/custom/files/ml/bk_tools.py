#!/usr/bin/python
#_*_coding:utf-8_*_

import os
import sys
import fcntl
import random
import ConfigParser

######################################
# 脚本执行互斥锁
# Usage: runLocker(__file__)
######################################

# 全局文件fd, 防止函数结束自动fd.close()
global g_pidfd

def runLocker(currFile):
    pidFile = "/tmp/" + os.path.basename(currFile).replace(".pyc", "").replace(".py", "") + ".pid"
    ret = doSigleton(pidFile)
    if ret != True:
        print "Process<%s> has running!!!" % currFile
        sys.exit(-1)

def doSigleton(pidFile):
    try:
        global g_pidfd
        g_pidfd = open(pidFile, 'w+')
        fcntl.flock(g_pidfd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return True
    except IOError:
        return False

######################################
# 读取配置文件bk_script.conf
# Usage: readFileCfg() | readFileCfg(./xxx.conf)
#        getFileCfg("env_g").registry_endpoint
######################################

class UtilCfgExcept(Exception):
    """ configer except """
    
class UtilCfgDict(dict):
    """ custom dict """
    def __getattr__(self, key):
        return self.get(key, None)
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__

class UtilFileCfger:
    def __init__(self, cfgFile=None):
        if cfgFile != None:
            self.read(cfgFile)
    
    def read(self, cfgFile):
        configer = ConfigParser.ConfigParser()
        configer.read(cfgFile)

        for section in configer.sections():
            setattr(self, section, UtilCfgDict())
            
            for name, rawValue in configer.items(section):
                try:
                    if configer.get(section, name) in ["0", "1"]:
                        raise ValueError
                    value = configer.getboolean(section, name)
                except ValueError:
                    try:
                        value = configer.getint(section, name)
                    except ValueError:
                        try:
                            value = configer.getfloat(section, name)
                        except ValueError:
                            value = configer.get(section, name)

                setattr(getattr(self, section), name, value)

    def get(self, section):
        try:
            return getattr(self, section)
        except AttributeError as e:
            raise UtilCfgExcept("Configer option<%s> is not exist, msg: %s" % (section, e))

g_defaultCfgFile = "/data/tools/bk_agent_script/bk_script.conf"
g_fileCfger = UtilFileCfger()

# 读文件配置
def readFileCfg(cfgFile = g_defaultCfgFile):
    g_fileCfger.read(cfgFile)

# 获取配置
def getFileCfg(section):
    return g_fileCfger.get(section)

######################################
# 解析HostList配置, 获取host和port
# Useage: hostPort = parseHostListCfg(getFileCfg("env_g").db_hostlist_hadoop)
#         print hostPort["host"]
#         print hostPort["port"]
######################################
def parseHostListCfg(hostlist):

    result = {}
    vHostInfo = hostlist.strip().split(";")
    idx = random.randint(0, len(vHostInfo) - 1)
    hostPort = vHostInfo[idx]

    vHostPort = hostPort.strip().split(":")
    if len(vHostPort) != 2:
        raise Exception("hostip fmt error: %s" % hostPort)
    
    result["host"] = vHostPort[0]
    result["port"] = int(vHostPort[1])

    if len(result) == 0:
        raise Exception("host_port return empty: %s" % hostlist)
    
    return result

if __name__ == "__main__":

    runLocker(__file__)

    readFileCfg("/home/sebachang/trunk_server/Script/bk_agent_script/bk_script.conf")
    print getFileCfg("global")
    print getFileCfg("global").app
    print getFileCfg("global").script_path
    print getFileCfg("env_g").registry_endpoint
    print getFileCfg("env_g").db_hostlist_hadoop
    
    print parseHostListCfg(getFileCfg("env_g").db_hostlist_hadoop)
    
