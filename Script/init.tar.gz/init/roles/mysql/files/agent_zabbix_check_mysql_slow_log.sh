#!/bin/bash

DIR=/data/mysql
SLOW_LOG=`ls ${DIR}/*slow.log`
SLOW_LOG_NUM=`cat ${SLOW_LOG} | wc -l`
DIGEST=/usr/local/bin/pt-query-digest
SAVE_SLOW_LOG_DIR=/data/tmp/percona_toolkit_slow.log
CHECK_MYSQL_SLOW_LOG=/tmp/check_mysql_slow_log.log

if [ ${SLOW_LOG_NUM} -gt 10 ];then
   echo "${SLOW_LOG_NUM}" >${CHECK_MYSQL_SLOW_LOG}
   ${DIGEST} ${SLOW_LOG} >${SAVE_SLOW_LOG_DIR} 2>&1
fi

>${SLOW_LOG}