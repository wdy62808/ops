#!/bin/sh
ip=$1
ip a|grep ${ip} >/dev/null
if [ $? -eq 0 ];then
  echo ${ip} #name
  echo ${ip}
else
  echo ${ip} #name
  echo "0.0.0.0"
fi