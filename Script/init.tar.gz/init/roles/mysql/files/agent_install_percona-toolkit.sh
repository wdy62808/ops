#!/bin/bash

INSTALL_DIR=/data/tmp/
DIGEST=/usr/local/bin/pt-query-digest
PACKAGE=${INSTALL_DIR}/percona-toolkit-2.2.2.tar.gz

function Install_Percona_Toolkit(){
  if [ ! -d ${INSTALL_DIR} ];then
     mkdir -p ${INSTALL_DIR}
  fi

  if [ ! -f ${DIGEST} ];then
     echo " Install Percona Toolkit! " >>/dev/null 2>&1
     cd ${INSTALL_DIR}
     yum -y install perl perl-DBD-MySQL perl-IO-Socket-SSL perl-Time-HiRes perl-ExtUtils-CBuilder perl-ExtUtils-MakeMaker

     if [ ! -f ${PACKAGE} ];then
        wget https://www.percona.com/downloads/percona-toolkit/2.2.2/percona-toolkit-2.2.2.tar.gz
     fi

     tar zxf percona-toolkit-2.2.2.tar.gz
     cd ${INSTALL_DIR}/percona-toolkit-2.2.2
     perl Makefile.PL 
     make && make test && make install
     ${DIGEST} --help >>/dev/null 2>&1
     Check=$?
        if [ $Check -ne 0 ];then
           echo "ERROR: Install Percona Toolkit Failed ！"
           exit 2
        fi
   fi
}

function Main(){
  Install_Percona_Toolkit
}

Main

#END