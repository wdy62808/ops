#!/bin/bash

if [[ $# -ne 2 ]]; then
  echo "Usage: $0 内网IP [1:多实例]"
  exit -1
fi

local_ip=$1
multi=$2

if [[ ! -f /data/tmp/Percona-Server-5.7.24-26-Linux.x86_64.ssl101.tar.gz ]]; then
   cd /data/tmp/;
   wget https://www.percona.com/downloads/Percona-Server-5.7/Percona-Server-5.7.24-26/binary/tarball/Percona-Server-5.7.24-26-Linux.x86_64.ssl101.tar.gz
fi

if [ "$multi" == "1" ]; then

# install mysql(多实例)
if [ ! -d /usr/local/percona ]; then

	tar -zxf /data/tmp/Percona-Server-5.7.24-26-Linux.x86_64.ssl101.tar.gz -C /usr/local/
	cd /usr/local
	ln -sv Percona-Server-5.7.24-26-Linux.x86_64.ssl101/ percona

	ln -sv /usr/local/percona/bin/my_print_defaults /usr/bin/my_print_defaults
	ln -sv /usr/local/percona/bin/mysql /usr/bin/mysql
	ln -sv /usr/local/percona/bin/mysqladmin /usr/bin/mysqladmin
	cd /usr/local/percona
  
	mkdir -p /data/percona
	groupadd -r mysql
	useradd -g mysql -r -s /sbin/nologin -M -d /data/percona mysql
	chown -R mysql:mysql /data/percona
	
	mkdir -p /data/percona_slave
	chown -R mysql:mysql /data/percona_slave

        /usr/local/percona/bin/mysqld --no-defaults --user=mysql  --datadir=/data/percona --initialize-insecure
        /usr/local/percona/bin/mysqld --no-defaults --user=mysql  --datadir=/data/percona_slave --initialize-insecure

       # 启动percona
       /usr/local/percona/bin/mysqld --no-defaults --user=mysql --datadir=/data/percona --tmpdir=/data/percona --plugin-dir=/usr/local/percona/lib/mysql/plugin --socket=/data/percona/percona.sock --pid-file=/data/percona/percona.pid --log-error=/data/percona/percona.log --bind-address=${local_ip} --port=3306 --skip-name-resolve --skip-grant-tables &
       sleep 3
       /usr/local/percona/bin/mysqld --no-defaults --user=mysql --datadir=/data/percona_slave/ --tmpdir=/data/percona_slave/ --plugin-dir=/usr/local/percona/lib/mysql/plugin --socket=/data/percona_slave/percona.sock --pid-file=/data/percona_slave/percona.pid --log-error=/data/percona_slave/percona.log --bind-address=${local_ip} --port=3307 --skip-name-resolve --skip-grant-tables &

       # 启用rocksdb插件
       sleep 3
       /usr/local/percona/bin/ps-admin --enable-rocksdb -h ${local_ip} -P 3306
       /usr/local/percona/bin/ps-admin --enable-rocksdb -h ${local_ip} -P 3307
       check=$?
       if [ $check -ne 0 ];then
          echo "启用rocksdb插件失败！"
          exit 1
       fi

       # 初始化用户
       echo "flush privileges; grant all on *.* to moba@'%' identified by 'moba2016' with grant option; grant all on *.* to replicate@'%' identified by 'moba2016'; reset master; shutdown;" | /usr/local/percona/bin/mysql -h ${local_ip} -P 3306
       echo "flush privileges; grant all on *.* to moba@'%' identified by 'moba2016' with grant option; grant all on *.* to replicate@'%' identified by 'moba2016'; reset master; shutdown;" | /usr/local/percona/bin/mysql -h ${local_ip} -P 3307
       check_user=$?
       if [ $check_user -ne 0 ];then
          echo "初始化用户失败！"
          exit 2
       fi

       # 编辑/usr/local/percona/my.cnf配置文件
	echo "[mysqld_multi]
	mysqld     = /usr/local/percona/bin/mysqld_safe
	mysqladmin = /usr/local/percona/bin/mysqladmin
	user       = moba
	pass       = moba2016

	[mysqld1]
	user                           = mysql
	sql_mode                       = NO_ENGINE_SUBSTITUTION,STRICT_TRANS_TABLES
        default-storage-engine         = ROCKSDB
	binlog-format                  = ROW
	log-bin                        = master-bin.log
	log-slave-updates              = 0
	gtid-mode                      = on
	enforce-gtid-consistency       = true
	master-info-repository         = FILE
	relay-log-info-repository      = FILE
	sync-master-info               = 10000
	binlog-checksum                = CRC32
	master-verify-checksum         = 1
	slave-sql-verify-checksum      = 1
	binlog-rows-query-log_events   = 1
	server-id                      = 11
	port                           = 3306
	datadir                        = /data/percona
	tmpdir                         = /data/percona
	log-error                      = /data/percona/percona.log
	pid-file                       = /data/percona/percona.pid
	socket                         = /tmp/percona.3306.sock
	bind-address                   = $local_ip
        slow_query_log                 = on
        long_query_time                = 0.1
        slow_query_log_file            = /data/percona/percona_slow.log
	binlog-ignore-db               = information_schema
	binlog-ignore-db               = mysql
	binlog-ignore-db               = test
	binlog-ignore-db               = performance_schema
	expire_logs_days               = 1
	relay_log                      = relay-bin
	max_connections                = 1000
	max_allowed_packet             = 128M
	default-storage-engine         = rocksdb
	rocksdb_use_fsync              = 1
	rocksdb_flush_log_at_trx_commit = 2
	secure_file_priv               = ''

	[mysqld2]
	user                           = mysql
	sql_mode                       = NO_ENGINE_SUBSTITUTION,STRICT_TRANS_TABLES
        default-storage-engine         = ROCKSDB
	binlog-format                  = ROW
	log-bin                        = master-bin.log
	log-slave-updates              = 0
	gtid-mode                      = on
	enforce-gtid-consistency       = true
	master-info-repository         = FILE
	relay-log-info-repository      = FILE
	sync-master-info               = 10000
	binlog-checksum                = CRC32
	master-verify-checksum         = 1
	slave-sql-verify-checksum      = 1
	binlog-rows-query-log_events   = 1
	server-id                      = 12
	port                           = 3307
	datadir                        = /data/percona_slave
	tmpdir                         = /data/percona_slave
	log-error                      = /data/percona_slave/percona.log
	pid-file                       = /data/percona_slave/percona.pid
	socket                         = /tmp/percona.3307.sock
	bind-address                   = $local_ip
	replicate-ignore-db            = information_schema
	replicate-ignore-db            = mysql
	replicate-ignore-db            = test
	replicate-ignore-db            = performance_schema
	expire_logs_days               = 1 
	relay_log                      = relay-bin
	max_connections                = 1000
	max_allowed_packet             = 128M
	relay_log_recovery             = 1
	slave-skip-errors              = 1062,1060
	default-storage-engine         = rocksdb
	rocksdb_use_fsync              = 1
	rocksdb_flush_log_at_trx_commit = 2
	secure_file_priv               = ''
	" > my.cnf
	
	echo "#!/bin/bash
	# chkconfig: 2345 64 36
	# description: start multi mysql process

	startMysqldMulti()
	{
		echo \"start mysqld_multi\"
                /usr/local/percona/bin/mysqld_multi --defaults-file=/usr/local/percona/my.cnf start
	}

	stopMysqldMulti()
	{
		echo \"stop mysqld_multi\"
                /usr/local/percona/bin/mysqld_multi --defaults-file=/usr/local/percona/my.cnf stop
	}

	restartMysqldMulti()
	{
		stopMysqldMulti
		startMysqldMulti
	}

	statusMysqldMulti()
	{
                ps aux | grep "/usr/local/percona/bin/mysqld" | grep -v grep
	}

	case \"\$1\" in
		start)
			startMysqldMulti
			;;
		stop)
			stopMysqldMulti
			;;
		restart)
			restartMysqldMulti
			;;
		status)
			statusMysqldMulti
			;;
		*)
			echo \"Please use start, stop, restart or status as first argument\"
			;;
	esac
	" > /etc/init.d/mysqld_multi

        sleep 10
	chmod +x /etc/init.d/mysqld_multi 
	chkconfig --add mysqld_multi
	chkconfig mysqld_multi on
	chkconfig mysqld_multi --list
	service mysqld_multi start
	netstat -ntulp

	echo "MANPATH /usr/local/percona/man" >> /etc/man.config
        ln -sv /tmp/percona.3306.sock /tmp/mysql.sock
        ln -sv /tmp/percona.3307.sock /tmp/mysql.sock2
	ln -sv /usr/local/percona/include/ /usr/include/mysql
	echo "export PATH=$PATH:/usr/local/percona/bin" > /etc/profile.d/mysql.sh
	source /etc/profile
	fi

else
        echo "单实例安装脚本已取消！"
        exit 1
fi
