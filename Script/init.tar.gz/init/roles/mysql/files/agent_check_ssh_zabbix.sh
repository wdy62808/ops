#!/bin/bash

#if [[ $# -lt 1 ]]; then
#        echo "Usage: $0 server [Check_ssh]"
#        exit -1
#fi

Cnf=/data/app/zabbix_agent/etc/zabbix_agentd.conf.j2
SenderFile=/tmp/check_ssh_zabbix_trapper.log
HostName=`grep 'ListenIP' $Cnf | awk -F '[=]' '{print $2}'`

function Check_ssh(){
pulic_ip=`(curl -s --connect-timeout 10 http://whatismyip.akamai.com/||curl -s --connect-timeout 10 ifconfig.me|| curl -s --connect-timeout 10 myip.ipip.net)|grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}'`
#pulic_ip=`curl -s http://whatismyip.akamai.com/`                                
ssh='\*:ssh'
sshv4_status=`/usr/sbin/ss -l |grep ":ssh" | awk '{print $4}'`			

>$SenderFile
>/tmp/check_ssh_zabbix.log
echo $sshv4_status |egrep "$ssh|$pulic_ip" 1>/dev/null 2>&1
if [ $? -ne 0 ]; then          #如果为0：表示SSH未监听外网IP地址，如果为1：表示SSH监听了外网IP地址
	ssh_status=0
	echo "0" >> /tmp/check_ssh_zabbix.log
	exit -1
fi

/sbin/service amazon_machine_iptables status 1>/dev/null 2>&1
if [ $? -ne 0 ]; then         #如果为0：表示防火墙已开启，如果为1：表示防火墙未开启
    firewall_status=1
else
    /sbin/service amazon_machine_iptables status | grep "dpt:22" 1>/dev/null 2>&1
    if [ $? -ne 0 ]; then     #如果为0：表示防火墙已开启并且对22端口有监听，如果为1：表示表示防火墙已开启但是未对22端口监听
        firewall_status=1
    else
        firewall_status=0
    fi
fi

if [ "$firewall_status"x = "1"x ] ; then
    echo "1" >> /tmp/check_ssh_zabbix.log
elif [ "$firewall_status"x = "0"x  ] ; then
    echo "0" >> /tmp/check_ssh_zabbix.log
fi
}
Check_ssh
#res=`Check_ssh`
#echo "$HostName Check_ssh $res" >> $SenderFile


#case "$1" in
#      Check_ssh)
#               Check_ssh
#               ;;
#      *)
#               echo "Usage: $0 server [Check_ssh]"
#               ;;
#esac


