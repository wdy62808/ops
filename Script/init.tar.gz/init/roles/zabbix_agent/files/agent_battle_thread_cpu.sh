#!/bin/bash

if [ $# -ne 1 ];then
  echo "Usage: $0 BattleServer"
  exit
fi

BattleServer=$1
server_pid=`ps -ef|grep "$BattleServer" |grep -v "grep"|grep -v "$0"|awk '{print $2}'`
thread_cpu=(1 2 3 4 5)
for i in $(seq 1 5)
do
  server_cpu_usage=`top -H -b -n 1 -p $server_pid |sed '1,/^$/d' | sed '1d;/^$/d' |sort -nrk9 |head -n1 |awk '{print $9}'|awk -F'.' '{print $1}'`
  num=`expr $i - 1`
  thread_cpu[$num]=$server_cpu_usage
done

len=${#thread_cpu[@]}
for((i=0; i<$len; i++)){
  for((j=i+1; j<$len; j++)){

    if [[ ${thread_cpu[i]} -gt ${thread_cpu[j]} ]]
    then
      temp=${thread_cpu[i]}
      thread_cpu[i]=${thread_cpu[j]}
      thread_cpu[j]=$temp
    fi
  }
}

#echo ${thread_cpu[@]}
echo ${thread_cpu[2]}
