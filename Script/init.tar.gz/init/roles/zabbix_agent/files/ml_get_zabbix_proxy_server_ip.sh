#!/bin/bash
region=$1

case $region in
  0)
    echo "zabbix.proxy.91"
    ;;
  1)
    echo "zabbix.proxy.1"
    ;;
  2)
    echo "zabbix.proxy.12"
    ;;

  3)
    echo "zabbix.proxy.3"
    ;;

  4)
    echo "zabbix.proxy.4"
    ;;

  5)
    echo "zabbix.proxy.5"
    ;;

  6)
    echo "zabbix.proxy.6"
    ;;

  7)
    echo "zabbix.proxy.7"
    ;;

  8)
    echo "zabbix.proxy.12"
    ;;

  9)
    echo "zabbix.proxy.12"
    ;;

  10)
    echo "zabbix.proxy.3"
    ;;

  11)
    echo "zabbix.proxy.3"
    ;;

  12)
    echo "zabbix.proxy.12"
    ;;

  *)
    echo "error"
    ;;
esac
