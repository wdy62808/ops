#!/bin/bash

ZBXSERVER=`cat /data/app/zabbix_agent/etc/zabbix_agentd.conf |grep -v "#Server=" |grep "Server=" |awk -F '=' '{print $2}'`
FPING=/usr/sbin/fping
ZBXSENDER=/data/app/zabbix_agent/bin/zabbix_sender

# How many ping to send
COUNT=$1
# What interval between ping [ms]
INTERVAL=$2
# How many bytes in one ping
BYTES=$3
# 'Hostname' of the host which will collect data

#HOSTNAME=$4

process="fping|agent_mobasmokeping"

#HOSTNAME=`/sbin/ifconfig | grep "inet addr:" | grep -v "127.0.0.1" | cut -d: -f2 | awk '{print$1}'`
HOSTNAME=`cat /data/app/zabbix_agent/etc/zabbix_agentd.conf |grep Hostname |awk -F '=' '{print $2}'`

IPLIST='169.46.180.116 169.57.143.243 119.81.9.203 119.81.162.23 159.253.134.60 159.122.113.148 169.56.72.40 8.8.8.8'

if [ $# -lt 3 ]
then
     echo
     echo " Not enough parameters"
     echo " Usage: agent_mobasmokeping.sh <NUMBERS_OF_PINGS> <INTERVAL> <BYTES> "
     echo " Zabbix External Check Item ex.: agent_mobasmokeping.sh 6 1000 68"
  exit 2
fi

if [ "$(ps aux | grep -E ${process} |grep -v "$$" |grep -v "grep" | awk '{print $2}')" == "" ];then
    echo "no process";

    else
    pids=$(ps aux | grep -E ${process} |grep -v "$$" | grep -v "grep" | awk '{print $2}')
    echo $pids
    for i in $pids;do
    kill -9 $i
    kill -9 $i
    done

fi

for TESTIP in ${IPLIST[@]}
do

if [ "$TESTIP"x = "169.46.180.116"x ] ; then
    IP=169.46.180.116
    OUTPUT=`$FPING -b $BYTES -c $COUNT -q -p $INTERVAL $IP 2>&1 | awk '{print $5,$8}' | tr -d "%|," | tr -s " " "/" | awk -F"/" '{print $3,$4,$5,$6}'`
    tab=($OUTPUT)
    $ZBXSENDER -z $ZBXSERVER -p 10051 -s $HOSTNAME -k DallasLoss -o ${tab[0]}
    $ZBXSENDER -z $ZBXSERVER -p 10051 -s $HOSTNAME -k DallasAvg -o ${tab[2]}

elif [ "$TESTIP"x = "169.57.143.243"x ] ; then
    IP=169.57.143.243
    OUTPUT=`$FPING -b $BYTES -c $COUNT -q -p $INTERVAL $IP 2>&1 | awk '{print $5,$8}' | tr -d "%|," | tr -s " " "/" | awk -F"/" '{print $3,$4,$5,$6}'`
    tab=($OUTPUT)
    $ZBXSENDER -z $ZBXSERVER -p 10051 -s $HOSTNAME -k BrazilLoss -o ${tab[0]}
    $ZBXSENDER -z $ZBXSERVER -p 10051 -s $HOSTNAME -k BrazilAvg -o ${tab[2]}

elif [ "$TESTIP"x = "119.81.9.203"x ] ; then
    IP=119.81.9.203
    OUTPUT=`$FPING -b $BYTES -c $COUNT -q -p $INTERVAL $IP 2>&1 | awk '{print $5,$8}' | tr -d "%|," | tr -s " " "/" | awk -F"/" '{print $3,$4,$5,$6}'`
    tab=($OUTPUT)
    $ZBXSENDER -z $ZBXSERVER -p 10051 -s $HOSTNAME -k SingaporeLoss -o ${tab[0]}
    $ZBXSENDER -z $ZBXSERVER -p 10051 -s $HOSTNAME -k SingaporeAvg -o ${tab[2]}

elif [ "$TESTIP"x = "119.81.162.23"x ] ; then
    IP=119.81.162.23
    OUTPUT=`$FPING -b $BYTES -c $COUNT -q -p $INTERVAL $IP 2>&1 | awk '{print $5,$8}' | tr -d "%|," | tr -s " " "/" | awk -F"/" '{print $3,$4,$5,$6}'`
    tab=($OUTPUT)
    $ZBXSENDER -z $ZBXSERVER -p 10051 -s $HOSTNAME -k HKLoss -o ${tab[0]}
    $ZBXSENDER -z $ZBXSERVER -p 10051 -s $HOSTNAME -k HKAvg -o ${tab[2]}

elif [ "$TESTIP"x = "159.253.134.60"x ] ; then
    IP=159.253.134.60
    OUTPUT=`$FPING -b $BYTES -c $COUNT -q -p $INTERVAL $IP 2>&1 | awk '{print $5,$8}' | tr -d "%|," | tr -s " " "/" | awk -F"/" '{print $3,$4,$5,$6}'`
    tab=($OUTPUT)
    $ZBXSENDER -z $ZBXSERVER -p 10051 -s $HOSTNAME -k NetherlandsLoss -o ${tab[0]}
    $ZBXSENDER -z $ZBXSERVER -p 10051 -s $HOSTNAME -k NetherlandsAvg -o ${tab[2]}

elif [ "$TESTIP"x = "159.122.113.148"x ] ; then
    IP=159.122.113.148
    OUTPUT=`$FPING -b $BYTES -c $COUNT -q -p $INTERVAL $IP 2>&1 | awk '{print $5,$8}' | tr -d "%|," | tr -s " " "/" | awk -F"/" '{print $3,$4,$5,$6}'`
    tab=($OUTPUT)
    $ZBXSENDER -z $ZBXSERVER -p 10051 -s $HOSTNAME -k GermanyLoss -o ${tab[0]}
    $ZBXSENDER -z $ZBXSERVER -p 10051 -s $HOSTNAME -k GermanyAvg -o ${tab[2]}

elif [ "$TESTIP"x = "169.56.72.40"x ] ; then
    IP=169.56.72.40
    OUTPUT=`$FPING -b $BYTES -c $COUNT -q -p $INTERVAL $IP 2>&1 | awk '{print $5,$8}' | tr -d "%|," | tr -s " " "/" | awk -F"/" '{print $3,$4,$5,$6}'`
    tab=($OUTPUT)
    $ZBXSENDER -z $ZBXSERVER -p 10051 -s $HOSTNAME -k KoreaLoss -o ${tab[0]}
    $ZBXSENDER -z $ZBXSERVER -p 10051 -s $HOSTNAME -k KoreaAvg -o ${tab[2]}


elif [ "$TESTIP"x = "8.8.8.8"x ] ; then
    IP=8.8.8.8
    OUTPUT=`$FPING -b $BYTES -c $COUNT -q -p $INTERVAL $IP 2>&1 | awk '{print $5,$8}' | tr -d "%|," | tr -s " " "/" | awk -F"/" '{print $3,$4,$5,$6}'`
    tab=($OUTPUT)
    $ZBXSENDER -z $ZBXSERVER -p 10051 -s $HOSTNAME -k GoogleLoss -o ${tab[0]}
    $ZBXSENDER -z $ZBXSERVER -p 10051 -s $HOSTNAME -k GoogleAvg -o ${tab[2]}

else
    IP=$1
    echo $IP
    exit -1

fi

done
