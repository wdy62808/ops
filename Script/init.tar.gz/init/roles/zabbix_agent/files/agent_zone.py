#!/usr/bin/env python
# -*- coding:utf8 -*-
# 监控时区脚本

import os,sys
import time,datetime

file_code = os.system("md5sum /etc/localtime | grep -E '(e99240e190c8a4ccf3cc0a26618fb09b|f1156019ae84feb984f360a049b3ebbe)' > /dev/null")

date_code = os.system("date -R | grep -E ' *\-0800$' > /dev/null")

#print file_code,date_code
if file_code == 0 and date_code == 0:
  pass
else:
  print ("/etc/localtime error")