#!/bin/bash
# 4G=4194304 8G=8388608 16G=16777216 32G=33554432 64G=67108864
df | sed '1d' | tr "\t" ' ' | tr -s ' ' |cut -d ' ' -f2,6 | sort -rn || echo "挂载分区计算失败" 2>/dev/null
res=`df | sed '1d' | tr "\t" ' ' | tr -s ' ' |cut -d ' ' -f2,6 | sort -rn | head -1 | cut -d ' ' -f2 || echo "最大的分区计算失败" 2>/dev/null`
if [ "$res" == "/home" ];then #表明占用空间最大的目录是home目录
  if [ -d /data ];then
    data_size=`du -s /data | tr "\t" ' ' | tr -d ' ' | cut -d '/' -f1`
    if [ ${data_size} -gt 1024 ];then
        echo "/data目录已经存在,而且容量超过1M,脚本终止!" 2>/dev/null
        exit 0
    else
        echo "将删除已存在的/data空目录" 2>/dev/null
        rm -rf /data
    fi
  fi
  echo "检测到分区挂载到/home下! 将自动创建软连接" 2>/dev/null
  mkdir -p /home/data && ln -s /home/data /data
  if [ "$?" == "0" ];then
      chown -R mulong:mulong /home/data
      echo "创建软连接成功" 2>/dev/null
      df -h
      ls -l /data
  else
      echo "创建软连接失败!" 2>/dev/null
      exit 1
  fi
fi

if [ ! -d /data ];then # 说明空间最大的目录的是根目录但没有对应的data目录
  mkdir /data && chown -R mulong:mulong /data
  echo "创建data目录"
fi

echo ""
free -h || free -g
now_swap=`free -g | grep Swap | tr "\t" ' ' | tr -s ' ' | cut -d ' ' -f2`
if [ -z $now_swap ];then
   echo "当前机器没有配置swap, 会自动处理"  2>/dev/null
   num=3
else
    now_mem=`free -g | grep Mem | tr "\t" ' ' | tr -s ' ' | cut -d ' ' -f2 || echo "总内存大下计算失败"  2>/dev/null`
    #bc_mem=`echo $((now_mem / 2 - 5)) || echo "比较内存算法错误" 2>/dev/null`
    bc_mem=`awk 'BEGIN {print int(0.3 * '$now_mem')}'|| echo "比较内存算法错误"  2>/dev/null`
    if [ $now_swap -gt $bc_mem ];then
        echo "当前机器配置swap满足需求 不做处理 !"  2>/dev/null
        echo "bc_mem "$bc_mem
        exit 0
    else
        echo "当前机器不足swap需求, 后续将会处理 !"  2>/dev/null
        num=3
    fi
fi
echo "num: "$num

#swap_total=`cat /proc/meminfo | grep SwapTotal |awk '{print $2}'`
#mem_total=`cat /proc/meminfo | grep MemTotal |awk '{print $2}'`
#num=`expr $mem_total / $swap_total`
mem_size=`free -m | grep 'Mem' |awk '{print $2}' || echo "内存大小计算失败" 2>/dev/null`
mkdir -p /data/swap

if [ $num -gt 2 -a $mem_size -gt 250000 -a $mem_size -lt 260000 ]; then
  dd if=/dev/zero of=/data/swap/swapfile bs=1024 count=67108864
  mkswap /data/swap/swapfile
  chmod 600 /data/swap/swapfile
  swapon /data/swap/swapfile || echo "创建swap分区失败" 2>/dev/null
  echo '/data/swap/swapfile swap swap defaults 0 0' >>/etc/fstab
  echo "自动挂载swap分区成功" 2>/dev/null
elif [ $num -gt 2 -a $mem_size -gt 120000 -a $mem_size -lt 130000 ]; then
  dd if=/dev/zero of=/data/swap/swapfile bs=1024 count=67108864
  mkswap /data/swap/swapfile
  chmod 600 /data/swap/swapfile
  swapon /data/swap/swapfile || echo "创建swap分区失败" 2>/dev/null
  echo '/data/swap/swapfile swap swap defaults 0 0' >>/etc/fstab
  echo "自动挂载swap分区成功" 2>/dev/null
elif [ $num -gt 2 -a $mem_size -gt 63000 -a $mem_size -lt 120000 ]; then
  dd if=/dev/zero of=/data/swap/swapfile bs=1024 count=33554432
  mkswap /data/swap/swapfile
  chmod 600 /data/swap/swapfile
  swapon /data/swap/swapfile || echo "创建swap分区失败" 2>/dev/null
  echo '/data/swap/swapfile swap swap defaults 0 0' >>/etc/fstab
  echo "自动挂载swap分区成功" 2>/dev/null
elif [ $num -gt 2 -a $mem_size -gt 31000 -a $mem_size -lt 60000 ]; then
  dd if=/dev/zero of=/data/swap/swapfile bs=1024 count=16777216
  mkswap /data/swap/swapfile
  chmod 600 /data/swap/swapfile
  swapon /data/swap/swapfile || echo "创建swap分区失败" 2>/dev/null
  echo '/data/swap/swapfile swap swap defaults 0 0' >>/etc/fstab
  echo "自动挂载swap分区成功" 2>/dev/null
elif [ $num -gt 2 -a $mem_size -gt 15000 -a $mem_size -lt 17000 ]; then
  dd if=/dev/zero of=/data/swap/swapfile bs=1024 count=8388608
  mkswap /data/swap/swapfile
  chmod 600 /data/swap/swapfile
  swapon /data/swap/swapfile || echo "创建swap分区失败" 2>/dev/null
  echo '/data/swap/swapfile swap swap defaults 0 0' >>/etc/fstab
  echo "自动挂载swap分区成功" 2>/dev/null
elif [ $num -gt 2 -a $mem_size -gt 7500 -a $mem_size -lt 9000 ]; then
  dd if=/dev/zero of=/data/swap/swapfile bs=1024 count=4194304
  mkswap /data/swap/swapfile
  chmod 600 /data/swap/swapfile
  swapon /data/swap/swapfile || echo "创建swap分区失败" 2>/dev/null
  echo '/data/swap/swapfile swap swap defaults 0 0' >>/etc/fstab
  echo "自动挂载swap分区成功" 2>/dev/null
else
  dd if=/dev/zero of=/data/swap/swapfile bs=1024 count=4194304
  mkswap /data/swap/swapfile
  chmod 600 /data/swap/swapfile
  swapon /data/swap/swapfile || echo "创建swap分区失败" 2>/dev/null
  echo '/data/swap/swapfile swap swap defaults 0 0' >>/etc/fstab
  echo "自动挂载swap分区成功" 2>/dev/null
fi
free -h || free -g