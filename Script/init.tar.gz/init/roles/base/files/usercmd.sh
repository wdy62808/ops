[ -d "/var/log/usercmd/$(whoami)" ] || mkdir -p /var/log/usercmd/$(whoami) 
[ -f "/var/log/usercmd/$(whoami)/$(date +%Y%m).log" ] &&  chattr +a /var/log/usercmd/$(whoami)/$(date +%Y%m).log &>/dev/null
export PROMPT_COMMAND='
msg="{\"time\":\"$( date +"%F %T" )\",\"login_user\":\"${NAME_OF_KEY-None}\",\"system_user\":\"$(whoami)\",\"pwd\":\"$(pwd)\",\"cmd\":\"$( history 1 | sed -r "s|^[ \t]+[0-9]+[ \t]+||" )\",$( who am i | sed -r "s|^([^ \t]+)[ \t]+([^ \t]+)[ \t]+(.+)[ \t]+\((.+)\)|\"from_user\":\"\1\",\"terminal\":\"\2\",\"remote_addr\":\"\4\"}|" ) \
    "; \
    echo "$msg" \
    >>/var/log/usercmd/$(whoami)/$(date +%Y%m).log
'