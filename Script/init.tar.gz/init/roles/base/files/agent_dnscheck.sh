#/bin/bash
echo_error() {    echo -ne "\033[31;1m $1\033[0m\n";}
echo_ok() {    echo -ne "\033[32;1m $1\033[0m\n";}
echo_warn() {    echo -ne "\033[33;1m $1\033[0m\n";}

dns_server=('114.114.114.114' '8.8.8.8')
nameserver=`grep "nameserver" /etc/resolv.conf|awk '{print $2}'`

if [ `grep "nameserver" /etc/resolv.conf|wc -l` -eq 0 ];then
        echo_error "resolv.conf配置文件中无nameserver配置，请检查."
        echo "nameserver 8.8.8.8" > /etc/resolv.conf
        echo_warn "已添加 nameserver 8.8.8.8,请注意检查网络是否正常"
        exit 0
else
    flag=0
    for namesvr in $nameserver;do
    if [[ "${dns_server[@]}" =~ "${namesvr}" ]];then
        flag=1
    fi
    done
    if [ $flag -eq 1 ];then
        echo_ok "DNS配置是$namesvr，正确"
        cat /etc/resolv.conf
        exit 0
    else
        echo "nameserver 8.8.8.8" >> /etc/resolv.conf
        cat /etc/resolv.conf
    fi
fi
