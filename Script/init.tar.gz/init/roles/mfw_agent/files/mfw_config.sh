#!/bin/bash

set -u
set -e

app=mfw
rootdir=/data
version_backup=$rootdir/version_backup
install_version_backup=$rootdir/version_install
unpack_path=$rootdir/version_release/$app
run_path=$rootdir/app/$app
tools_path=$rootdir/tools
mfw_script_path=$tools_path/mfw_script

build_path=/usr/local/mfw/server
src_path=..
#script_path=/usr/local/mfw/script/mfw 正式版本脚本路径

all_svr=(mfwlog mfwregistry mfwcontrol mfwagent)

function get_env_config()
{
    if [[ $# -lt 1 ]]; then
        echo "Usage: $0 (d:开发环境，g：正式环境)"
        exit -1
    fi
    rel_env=$1
    case $rel_env in
        d)
        registry_endpoint='tcp -h 192.168.40.210 -p 2000 -t 600000'
        cc_ip=192.168.40.210
        rel_user=mulong
        rel_passwd=mulong
        registry_db_host=192.168.40.210
        registry_db_port=3306
        registry_db_user=root
        registry_db_pass=game123
        ;;
        u)
        registry_endpoint='tcp -h 10.162.84.200 -p 2000 -t 600000'
        cc_ip=169.46.180.116
        rel_user=mulong
        rel_passwd=mulong2016
        registry_db_host=10.162.84.200
        registry_db_port=3306
        registry_db_user=moba
        registry_db_pass=moba2016
        ;;
        g)
        registry_endpoint='tcp -h 10.84.248.207 -p 2000 -t 600000:tcp -h 10.84.248.220 -p 2000 -t 600000'
        cc_ip=169.46.180.116
        rel_user=mulong
        rel_passwd=mulong2016
        registry_db_host=10.86.92.213
        registry_db_port=13306
        registry_db_user=moba
        registry_db_pass=moba2016
        ;;
        *)
        echo "$rel_env is not valid param, it should be \"d\" or \"r\" "
        exit 10
        ;;
    esac
}

get_env_config g
