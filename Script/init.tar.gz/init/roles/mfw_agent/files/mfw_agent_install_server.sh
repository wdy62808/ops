#!/bin/bash
#agent服务器自身调用安装

if [ $# -lt 3 ]; then
	echo "Usage: $0 pack_name server_name dst_ip"
	exit -1
fi
source mfw_config.sh
pack_name=$1
server=`echo $pack_name |cut -d "-" -f2`
server_name=$2
dst_ip=$3

echo ">>> unpack $pack_name ..."
mkdir -p $unpack_path
if [ -f $install_version_backup/$pack_name ]; then 
	tar zxf $install_version_backup/$pack_name -C $unpack_path 
else
	echo "cannot find file : $install_version_backup/$pack_name"
	exit -1
fi

echo ">>> stop $server_name ..."
if [ -f $run_path/$server_name/stop.sh ]; then 
	echo "run stop.sh"
	$run_path/$server_name/stop.sh 
fi

echo ">>> copy $server_name ..."
mkdir -p $run_path

if [ "$server" == "$server_name" ]; then
	cp -r $unpack_path/$server $run_path
else
	#mfwlog可能的特殊需求
	mkdir -p $run_path/$server_name
	cp $unpack_path/$server/*.sh $run_path/$server_name/
	cp $unpack_path/$server/$server.conf $run_path/$server_name/$server_name.conf
	cp $unpack_path/$server/$server.mfw.conf $run_path/$server_name/$server_name.mfw.conf
	sed -i "s/$server/$server_name/g" $run_path/$server_name/*.sh
	sed -i "s/$server/$server_name/g" $run_path/$server_name/*.conf
	cp $unpack_path/$server/$server $run_path/$server_name/$server_name
fi

chmod a+x $run_path/$server_name/*.sh
chmod a+x $run_path/$server_name/$server_name

if [ -f $run_path/$server_name/$server_name.mfw.conf ]; then
	sed -i -e "s/TEMPLATE_REGISTRY_ENDPOINT/$registry_endpoint/g" $run_path/$server_name/$server_name.mfw.conf
	sed -i -e "s/TEMPLATE_ServerIP/$dst_ip/g" $run_path/$server_name/$server_name.mfw.conf
fi
sed -i -e "s/TEMPLATE_ServerIP/$dst_ip/g" $run_path/$server_name/$server_name.conf
sed -i -e "s/TEMPLATE_RegistryDbHost/$registry_db_host/g" $run_path/$server_name/$server_name.conf
sed -i -e "s/TEMPLATE_RegistryDbUser/$registry_db_user/g" $run_path/$server_name/$server_name.conf
sed -i -e "s/TEMPLATE_RegistryDbPasswd/$registry_db_pass/g" $run_path/$server_name/$server_name.conf
# endpoint config
if [ -f $run_path/$server_name/$server_name.mfw.conf ];then
	for service in $(grep "TEMPLATE_ENDPOINT_" $run_path/$server_name/$server_name.mfw.conf|awk -F"TEMPLATE_ENDPOINT_" {'print $2'}); do
		service=`echo $service | sed 's/[\t\r\n]*//g;'`
		endpoint_sql="select endpoint from db_mfw.t_service where app='$app' and server='$server_name' and service='$service' and node='$dst_ip'"
		endpoint=$(echo "$endpoint_sql"|mysql -h$registry_db_host -u$registry_db_user -p$registry_db_pass -N)
		sed -i -e "s/TEMPLATE_ENDPOINT_$service/$endpoint/g" $run_path/$server_name/$server_name.mfw.conf
	done
fi

echo ">>> start $server_name ..."
$run_path/$server_name/start.sh 

