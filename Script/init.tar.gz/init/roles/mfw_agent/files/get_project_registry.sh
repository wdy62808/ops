#!/bin/bash
case "$1" in
   "ml")
        #ml_registry_endpoint
        source /data/tools/script/config.sh
        echo "$registry_endpoint"
        #echo "tcp -h 10.84.248.207 -p 2000:tcp -h 10.84.248.220 -p 2000:tcp -h 10.154.35.185 -p 2000:tcp -h 10.154.35.194 -p 2000"
        ;;
   "sc")
       #sc_registry_endpoint
       echo "tcp -h 10.7.8.10 -p 2000:tcp -h 10.7.8.11 -p 2000:tcp -h 10.7.12.2 -p 2000"
       ;;
   *)
       echo "请填写正确项目名称"
       exit 1
esac
