#!/bin/bash

if [[ $# -lt 2 ]]; then
	echo "Usage: $0 pack_name install_server_name(mfwlog可能按照多个服务名安装) [ip]"
	exit -1
fi

source mfw_config.sh
source mfw_remote_cmd.sh
source mfw_func.sh
pack_name=$1
install_server=$2
pack_server=`echo $pack_name |cut -d "-" -f2`
if ! checkSvrName $pack_server ; then
	echo "$pack_server is not install_server name"
	exit 2
fi

if [[ $# == 3 ]]; then
	ip=$3
	runcmd $rel_user@$ip "cd $mfw_script_path; ./mfw_agent_install_server.sh $pack_name $install_server $ip"
else
	getServerIp -s $install_server -r global_ip
	for ip in $global_ip; do
		runcmd $rel_user@$ip "cd $mfw_script_path; ./mfw_agent_install_server.sh $pack_name $install_server $ip"
	done
fi

echo ">>> $0 success"
exit 0
