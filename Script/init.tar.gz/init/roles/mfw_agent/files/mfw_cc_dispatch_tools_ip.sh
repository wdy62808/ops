#!/bin/bash
if [[ $# -ne 1 ]]; then
	echo "Usage: $0 dst_ip"
	exit -1
fi

source mfw_remote_cmd.sh
source mfw_config.sh
dst_ip=$1

agent_tools=tmp_tools
agent_tools_pack=mfw_agent-tools.tar.gz

mkdir -p $agent_tools/mfw_script
cp mfw_agent_install_server.sh $agent_tools/mfw_script
cp mfw_cc_release_agent.sh $agent_tools/mfw_script
cp mfw_cc_dispatch_server_ip.sh $agent_tools/mfw_script
cp mfw_cc_dispatch_tools_ip.sh $agent_tools/mfw_script
cp mfw_cc_install_server.sh $agent_tools/mfw_script
cp mfw_config.sh $agent_tools/mfw_script


tar czf $agent_tools_pack -C $agent_tools ./

runcmd mulong@$dst_ip "mkdir -p $tools_path"
putfile mulong@$dst_ip $agent_tools_pack /data/tmp
runcmd mulong@$dst_ip "tar zxf /data/tmp/$agent_tools_pack -C $tools_path "

rm $agent_tools_pack
rm -rf $agent_tools

