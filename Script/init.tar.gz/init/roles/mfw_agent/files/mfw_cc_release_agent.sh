#!/bin/bash

if [[ $# -lt 1 ]]; then
	echo "Usage: $0 内网ip"
	exit 1 
fi

dst_ip=$1
pack_name=`ls -t /data/version_backup/mfw-mfwagent-* 2>/dev/null|head -n1|sed 's/\/data\/version_backup\///g'`
if [ "$pack_name" == "" ]; then
	echo "/data/version_backup目录下没有mfwagent文件"
	exit 2
fi
source mfw_config.sh
source mfw_remote_cmd.sh
source mfw_func.sh

./mfw_cc_dispatch_tools_ip.sh $dst_ip
./mfw_cc_dispatch_server_ip.sh $pack_name $dst_ip

./mfw_cc_install_server.sh $pack_name mfwagent $dst_ip
