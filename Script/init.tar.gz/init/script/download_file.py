#!/usr/bin/env python
# -*- coding: utf8 -*-
import datetime
import hashlib
import hmac
import sys
import os

import urllib
from contextlib import closing

Usage = """
%s private/public src dest_path
""" % sys.argv[0]

if len(sys.argv) != 4:
    print Usage
    sys.exit(1)

label = sys.argv[1]
src = sys.argv[2]
dest = sys.argv[3]


def hash(key, msg):
    return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()


# region is a wildcard value that takes the place of the AWS region value
# as COS doen't use regions like AWS, this parameter can accept any string
def createSignatureKey(key, datestamp, region, service):
    keyDate = hash(('AWS4' + key).encode('utf-8'), datestamp)
    keyRegion = hash(keyDate, region)
    keyService = hash(keyRegion, service)
    keySigning = hash(keyService, 'aws4_request')
    return keySigning


class ibm_bucket(object):
    def __init__(self, label, src, dest_path=None):
        self.url_label = label
        self.access_key = '5d0fc3187eca4e4d94fa34d1a7ddccc6'
        self.secret_key = '557d665edf7d946d15a2fe36a83c0452032f072710dbc6ef'
        self.http_method = 'GET'
        self.region = ''
        self.bucket = 'ops-ibm-storage'
        self.cos_endpoint = dict(private='s3.private.us-south.cloud-object-storage.appdomain.cloud',
                                 public='s3.us-south.cloud-object-storage.appdomain.cloud')
        self.host = self.cos_endpoint[self.url_label]
        self.endpoint = 'https://' + self.host
        self.object_key = src
        self.dest = dest_path + '/' + src.split('/')[-1]
        self.expiration = 86400  # time in seconds

    def get_request_url(self):
        # assemble the standardized request
        time = datetime.datetime.utcnow()
        timestamp = time.strftime('%Y%m%dT%H%M%SZ')
        datestamp = time.strftime('%Y%m%d')

        standardized_querystring = ('X-Amz-Algorithm=AWS4-HMAC-SHA256' +
                                    '&X-Amz-Credential=' + self.access_key + '/' + datestamp + '/' + self.region + '/s3/aws4_request' +
                                    '&X-Amz-Date=' + timestamp +
                                    '&X-Amz-Expires=' + str(self.expiration) +
                                    '&X-Amz-SignedHeaders=host')
        standardized_querystring_url_encoded = urllib.quote(standardized_querystring, safe='&=')

        standardized_resource = '/' + self.bucket + '/' + self.object_key
        payload_hash = 'UNSIGNED-PAYLOAD'
        standardized_headers = 'host:' + self.host
        signed_headers = 'host'

        standardized_request = (self.http_method + '\n' +
                                standardized_resource + '\n' +
                                standardized_querystring_url_encoded + '\n' +
                                standardized_headers + '\n' +
                                '\n' +
                                signed_headers + '\n' +
                                payload_hash)

        # assemble string-to-sign
        hashing_algorithm = 'AWS4-HMAC-SHA256'
        credential_scope = datestamp + '/' + self.region + '/' + 's3' + '/' + 'aws4_request'
        sts = (hashing_algorithm + '\n' +
               timestamp + '\n' +
               credential_scope + '\n' +
               hashlib.sha256(standardized_request).hexdigest())

        # generate the signature
        signature_key = createSignatureKey(self.secret_key, datestamp, self.region, 's3')
        signature = hmac.new(signature_key,
                             (sts).encode('utf-8'),
                             hashlib.sha256).hexdigest()

        request_url = (self.endpoint + '/' +
                       self.bucket + '/' +
                       self.object_key + '?' +
                       standardized_querystring_url_encoded +
                       '&X-Amz-Signature=' +
                       signature)
        return request_url

    def download_file_to_s3(self):
        request_url = self.get_request_url()
        if os.path.exists(self.dest):
            os.remove(self.dest)
        with closing(urllib.urlopen(request_url)) as dl_file:
            with open(self.dest, 'wb') as f:
                    f.write(dl_file.read())


s3 = ibm_bucket(label, src, dest)
s3.download_file_to_s3()

