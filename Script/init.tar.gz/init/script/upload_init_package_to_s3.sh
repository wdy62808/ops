#!/bin/bash
export AWS_ACCESS_KEY_ID=5d0fc3187eca4e4d94fa34d1a7ddccc6
export AWS_SECRET_ACCESS_KEY=557d665edf7d946d15a2fe36a83c0452032f072710dbc6ef

Usage(){
    echo "$0: private/public 'all' 脚本指定文件上传到S3"
    echo "$0: private/public 'file' file_name dir 上传文件到S3"
    echo "$0: private/public 'dir' dir_name target_dir 上传目录到S3"
    echo "$0: private/public 'get' path 下载S3文件"
    exit 1
}

if [ $# -lt 2 ];then
    Usage
fi

if [[ "$1" == "private" ]];then
    url=https://s3.private.us-south.cloud-object-storage.appdomain.cloud
elif [[ "$1" == "public" ]];then
    url=https://s3.us-south.cloud-object-storage.appdomain.cloud
else
    Usage
fi

file_list=(/data/config_backup/tools/bk_package/install_geoip/update.zip /data/version_backup/mfw-mfwagent-20160415.tar.gz /data/config_backup/tools/bk_package/install_mysql/5.7/Percona-Server-5.7.24-26-Linux.x86_64.ssl101.tar.gz /data/config_backup/tools/bk_package/install_mysql/5.7/percona-toolkit-2.2.2.tar.gz /data/config_backup/tools/bk_package/install_mysql/5.7/percona-xtrabackup-24-2.4.12-1.el6.x86_64.rpm /data/config_backup/tools/bk_package/install_raid/1.21.16_StorCLI.zip /data/config_backup/tools/bk_package/install_redis/redis.tar.gz /data/config_backup/tools/bk_package/install_zabbix_agent/zabbix_agent.tar.gz /data/tools/TestTools/test_relay)
target_dir=(init/geoip/ init/mfwagent/ init/mysql/ init/mysql/ init/mysql/ init/raid/ init/redis/ init/zabbix/ init/test_relay)

function upload_all_file(){
    for((i=0;i<${#file_list[@]};i++))
    do
        echo ${file_list[i]} ${target_dir[i]}
        aws --endpoint-url=${url} s3 cp ${file_list[i]} s3://ops-ibm-storage/${target_dir[i]} 
    done
}

function upload_file(){
    file=$1
    dir=$2
    aws --endpoint-url=${url} s3 cp ${file} s3://ops-ibm-storage/${dir}/ 2>/dev/null 
}

function upload_dir(){
   sdir=$1
   tdir=$2
   aws --endpoint-url=${url} s3 sync ${sdir} s3://ops-ibm-storage/${tdir}/ 2>/dev/null 
}

function get_file(){
   file=$1
   local_path=$2
   aws --endpoint-url=${url} s3 cp s3://ops-ibm-storage/$file $local_path
}

if [[ "$2" == "all" ]];then
    upload_all_file
elif [[ "$2" == "file" ]];then
    upload_file $3 $4
elif [[ "$2" == "dir" ]];then
    upload_dir $3 $4
elif [[ "$2" == "get" ]];then
    get_file $3 $4
elif [[ "$2" == "ls" ]];then
    aws --endpoint-url=${url} s3 ls s3://ops-ibm-storage/init/geoip/
else
    Usage
fi
